﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace График_функции
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public double Func1(double x)
        {
            if (x <= 13)
            {
                return -Math.Pow(x, 3) + 9;
            }
            else
            {
                return -(3 / (x + 1));
            }
        }
        public double Func2(double x)
        {
            return 2 * Math.Tan(x / 2) + 1;
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {

            int W = this.Width, H = this.Height; // размеры формы
            float halfW = W / 2, halfH = H / 2; // середина формы
            // оси координат
            e.Graphics.DrawLine(Pens.Black, halfW, 0, halfW, H);
            e.Graphics.DrawLine(Pens.Black, 0, halfH, W, halfH);
            //границы интервала для аргумента функции
            //в математической системе координат
            double a = -9; double b = 10;//x_min, x_max
            double y_min = -10; double y_max = 15;
            //шаг аргумента функции
            double h = (b - a) / W;
            //начальное значение аргумента
            double x = a;
            double yp = Func1(x);
            double yp2 = Func2(x);
            int xgp = (int)Math.Round(W / (b - a) * (x - a));
            int ygp = H + (int)Math.Round(-H / (y_max - y_min) * (yp - y_min));
            int ygp2 = H + (int)Math.Round(-H / (y_max - y_min) * (yp2 - y_min));
            //цикл по оси Х графического окна
            for (int i = 0; i < W; i++)
            {               
                //математическое значение функции
                double y = Func1(x);
                double y2 = Func2(x);
                //графические координаты
                int xg = (int)Math.Round(W/(b - a)*(x -a));
                int yg = H + (int)Math.Round(-H/(y_max - y_min)*(y - y_min));
                //построение точки
                int yg2 = H + (int)Math.Round(-H / (y_max - y_min) * (y2 - y_min));
                e.Graphics.DrawLine(Pens.Red, xgp, ygp, xg,yg);
                xgp = xg;
                ygp = yg;
                e.Graphics.DrawLine(Pens.Blue, xgp, ygp2, xg, yg2);
                ygp2 = yg2;          
                 //изменение аргумента функции
                x += h;


            }

            
        }
    
    }
}
