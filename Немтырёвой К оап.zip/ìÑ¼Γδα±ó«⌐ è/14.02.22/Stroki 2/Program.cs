﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Stroki_2
{
    class Program
    {
        static void Main(string[] args)
        {
            //Напишите программу, которая выводит слова введённой строки (части, разделённые символами пустого пространства) в столбик.
            Console.WriteLine("Задание 1");
            string stroka = Console.ReadLine();
            string[] stroki = stroka.Split();
            foreach (string c in stroki)
            {
                Console.WriteLine(c);
            }
            Console.ReadKey();

            //Напишите программу, которая выбирает из введённой строки каждое третье слово. Слова разделены пробелами. Знаки препинания считать частью слова, даже если это приводит к неверной пунктуации.
            Console.WriteLine("Задание 2");
            string a2 = Console.ReadLine(); 
            string[] slova = a2.Split(' '); 
            for (int i = 2; i < slova.Length; i += 3) 
            { 
                Console.WriteLine(slova[i]);
            }
            
            Console.ReadKey();

            //Вводятся несколько слов на одной строке, разделённые символами пустого пространства. Гарантируется, что в словах не встречается апостроф (одинарная кавычка) и обратный слэш. Нужно вывести те же слова, но помещённые в двойные кавычки, разделённые запятыми с пробелом и обёрнутые в квадратные скобки.
            Console.WriteLine("Задание 3");
            string a3 = Console.ReadLine();
            string[] s = a3.Split();
            string s1 = string.Join("\", \"", s);
            Console.WriteLine(s1);
            Console.WriteLine(String.Concat("[\"", s1, "\"]"));
            Console.ReadKey();

            /*1.	На первой строке вводится натуральное число N — количество пунктов рецепта.
Далее следуют N строк — пункты рецепта. Вывести в одну строку пункты рецепта, разделённые запятой
            и пробелом, без пунктов с упоминанием лука (то есть таких, в которых нет подстроки "лук" в нижнем регистре).*/
            int N = int.Parse(Console.ReadLine());
            for (int i=0; i<N; i++)
            {
                string stroka3 = Console.ReadLine();
                if (!stroka3.Contains("лук"));

            }

            
        }
    }
}
