﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace PR13
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Практическая работа №13");
            Console.WriteLine("Выполнила студентка 2 курса группы ИСП.20А");
            Console.WriteLine("Мальчик Артём");
            //запись исходных данных в файл Input.txt
            string path = @"Input.txt";
            double C1 = 2e-6;
            double C2 = 0.16e-5;
            double C3 = 125e-4;
            StreamWriter sw = new StreamWriter(path, false);
            sw.WriteLine(C1);
            sw.WriteLine(C2);
            sw.WriteLine(C3);
            sw.Close();
            Console.WriteLine("Исходные данные:");            
            Console.WriteLine($"C1 = {C1}");
            Console.WriteLine($"C2 = {C2}");
            Console.WriteLine($"C3 = {C3}");
            Console.WriteLine("Запись произведена");
            Console.ReadKey();


            //чтение из файла Input.txt
            StreamReader sr = new StreamReader(path);
            double C1_read = Convert.ToDouble(sr.ReadLine());
            double C2_read = Convert.ToDouble(sr.ReadLine());
            double C3_read = Convert.ToDouble(sr.ReadLine());

            //вычисление результата по формуле
            double solve = 1/C1_read + 1 / C2_read + 1 / C3_read;//формула
            solve = 1 / solve;

            //запись результата в файл Result.txt
            string path1 = @"Result.txt";
            StreamWriter sw1 = new StreamWriter(path1, false);
            sw1.WriteLine(solve);
            sw1.Close();
            Console.WriteLine($"Результат: {solve}");
            Console.WriteLine("Подсчет и запись выполнены");
            Console.ReadKey();
        }
    }
}
