﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MnozestvaZadachi
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Задание 12");
            string[] M = { "Mercury", "Venus","Neptune", "Earth", "Jupiter" };
            string[] T = { "Mercury", "Earth", "Mars", "Jupiter" };
            var result = M.Intersect(T);
            Console.WriteLine("Совпадающие элементы множества:");
            Print_mnozh(result);
            Console.WriteLine($"Количество совпадающих элементов: {result.Count()}");
            

            Console.WriteLine("Задание 14");
            HashSet<int> A = new HashSet<int>();            
            Console.WriteLine("Введите элементы множества А (чтобы перейти на ввод следующего множества нажмите Enter)");
            while (true)
            {                
                try
                {
                    A.Add(int.Parse(Console.ReadLine()));
                }
                catch
                { break; }
            }
            HashSet<int> B = new HashSet<int>();
            Console.WriteLine("Введите элементы множества B");
            while (true)
            {
                try
                {
                    B.Add(int.Parse(Console.ReadLine()));
                }
                catch
                { break; }
            }
            Console.WriteLine("Элементы, содержащиеся и в первом и во втором множестве");
            var result1 = A.Intersect(B);
            Print_mnozh1(result1);
            Exit();
        }
        private static void Print_mnozh(IEnumerable<string> res)
        {
            foreach (string s in res)
                Console.WriteLine(s);
        }
        private static void Exit()
        {
            ConsoleKeyInfo cki = Console.ReadKey();
            while (cki.Key != ConsoleKey.K)
            {
                Console.WriteLine("Вы не нажали K");
                cki = Console.ReadKey(false);
            }
        }
        private static void Print_mnozh1(IEnumerable<int> res1)
        {
            foreach (int c in res1)
                Console.WriteLine(c);
        }
    }
}
