﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PR13
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Немтырёвой Ксении");
            Console.WriteLine("Практическая работа №13, варниант 2");
            Console.WriteLine("Задание 1");
            Console.WriteLine("Сформировать массив. Найти сумму положительных элементов.");
            Random rand = new Random();
            int[] B = new int[7];
            long summa = 0;
            Console.WriteLine("Массив:");
            for (int i = 0; i < 7; i++)
            {
                B[i] = rand.Next(-100, 100);
                Console.WriteLine($"{B[i]} ");
                if (B[i] > 0)
                {
                    summa += B[i];
                }
            }
            Console.WriteLine($"Сумма положительных элементов: {summa}");
            Console.ReadKey();

            Console.WriteLine("Задание 2");
            Console.WriteLine("Дана последовательность из N  вещественных чисел. Определить, сколько в ней чисел меньше K, равно K и больше K.");            
            int menshe = 0;
            int ravno = 0;
            int bolshe = 0;

            Console.WriteLine("Укажите размер массива:");           
            int N = Convert.ToInt32(Console.ReadLine());
            double[] massiv = new double[N];
            Random rand2 = new Random();
            for (int i = 0; i < massiv.Length; i++)
            {
                massiv[i] = rand2.NextDouble()*1000-500;
                Console.WriteLine($"{massiv[i]} ");
            }
            Console.WriteLine("Введите K");
            int K = int.Parse(Console.ReadLine());
            for (int i = 0; i < massiv.Length; i++)
            {
                if (massiv[i] < K)
                {
                    menshe++;
                }
                if (massiv[i] == K)
                {
                    ravno++;
                }
                if (massiv[i] > K)
                {
                    bolshe++;
                }
            }
            Console.WriteLine($"Количество элементов меньше K:{menshe}");
            Console.WriteLine($"Количество элементов равно K:{ravno}");
            Console.WriteLine($"Количество элементов больше K:{bolshe}");
            Console.ReadKey();

        }
    }
}
