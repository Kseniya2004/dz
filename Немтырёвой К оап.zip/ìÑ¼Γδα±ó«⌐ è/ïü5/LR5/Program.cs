﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LR5
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Лабораторная работа №5");
            Console.WriteLine("Выполнила студентка 2 курса группы ИСП.20А");
            Console.WriteLine("Немтырёва Ксения");
            Console.WriteLine("14.	Вывести имя в обратном порядке.");
            Console.WriteLine("Введите ФИО");
            string fio = Console.ReadLine();
            int sim = fio.Length;
            string[] massive = fio.Split(' ');
            string name = "";
            foreach (char c in massive[1])
            {
               name = c + name;                
            }
            Console.WriteLine("------");
            Console.WriteLine(fio);
            Console.WriteLine($"Количество символов в строке: {sim}");
            Console.WriteLine(name);
            Console.ReadKey();

        }
    }
}
