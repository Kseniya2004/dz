﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _24._02._2022
{
    class Program
    {
        static void Main(string[] args)
        {
            // (1 2 5) 1 2 3 4 5 9 10 11 12
            //Console.WriteLine("Немтырёва Ксения");
            //Console.WriteLine("Задание 1");
            //Console.WriteLine("Введите натурально число k =");
            //int k = int.Parse(Console.ReadLine());
            //Random rand = new Random();
            //Console.WriteLine("Введите размер массива");
            //int N = int.Parse(Console.ReadLine());
            //int[] A = new int[N];
            //long summa = 0;
            //for (int i = 0; i < N; i++)
            //{
            //    A[i] = rand.Next(int.MaxValue);
            //    Console.WriteLine($"{A[i]} ");
            //    if(A[i] % k == 0)
            //    {
            //        summa += A[i];
            //    }
            //}
            //Console.WriteLine($"Сумма элементов кратных {k}, равна {summa}");
            //Console.ReadKey();

            //Console.WriteLine("Задание 2");
            //int[] M1 = { 1, -2, 0, 3333, 5, 0, -63636, 0, 7655 };
            //int countZero = 0;
            //Console.WriteLine("Исходный массив");
            //foreach (int m in M1)
            //{
            //    Console.WriteLine(m);
            //    if (m == 0)
            //        countZero++;
            //}
            //int[] M2 = new int[countZero];
            //int j = 0;
            //for(int i=0; i < M1.Length; i++)
            //{
            //    if(M1[i] == 0)
            //    {
            //        M2[j] = i;
            //        j++;
            //    }
            //}
            //Console.WriteLine("Массив из номеров нулей");
            //foreach(int m in M2)
            //{
            //    Console.WriteLine(m);
            //}
            //Console.ReadKey();

            //Console.WriteLine("Задание 5");
            //int[] M1 = { 1, -2, 0, 3333, 5, 0, -63636, 0, 7652 };
            //int count = 0;
            //Console.WriteLine("Исходный массив");
            //foreach (int m in M1)
            //{
            //    Console.WriteLine(m);
            //    if (m%2 == 0)
            //        count++;
            //}
            //int[] M2 = new int[count];
            //int j = 0;
            //foreach (int m in M1)
            //{
            //    if (m%2 == 0)
            //    {
            //        M2[j] = m;
            //        j++;
            //    }
            //}
            //Console.WriteLine("Массив из номеров чётных чисел");
            //foreach (int m in M2)
            //{
            //    Console.WriteLine(m);
            //}
            //Console.ReadKey();

            //3. если 0 то идёт дальше

        }
    }
}
