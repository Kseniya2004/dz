﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _02._03._22
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Элементов в строке");
            int NewN = int.Parse(Console.ReadLine());
            Console.WriteLine("Элементов в столбце");
            int M = int.Parse(Console.ReadLine());
            int newM = M;
            int[,] mas = new int[NewN, newM];
            Random R = new Random();
            int max = 0; int imax = 0; int jmax = 0;
            int min = 0; int imin = 0; int jmin = 0;
            Console.WriteLine("Исходный массив");
            PrintMas(NewN, newM, mas, R, ref max, ref imax, ref jmax, ref min, ref imin, ref jmin);
            Console.WriteLine($"Максимальное значение элемента: {max}, [{imax},{jmax}] ");
            Console.WriteLine($"Минимальное значение элемента: {min}, [{imin},{jmin}]");
            Console.WriteLine("Результат:");
            for (int i = 0; i < NewN; i++)
            {
                for (int j = 0; j < newM; j++)
                {

                    Console.Write($"{mas[i, j]}\t");
                }
                Console.WriteLine();
            }
            Console.WriteLine($"Теперь максимальное значение элемента: {max}, [{imin},{jmin}] ");
            Console.WriteLine($"Теперь минимальное значение элемента: {min}, [{imax},{jmax}]");
            Console.ReadKey();
        }

        private static void PrintMas(int N, int M, int[,] mas, Random R, ref int max, ref int imax, ref int jmax, ref int min, ref int imin, ref int jmin)
        {
            for (int i = 0; i < N; i++)
            {
                for (int j = 0; j < M; j++)
                {
                    mas[i, j] = R.Next(-100, 100);
                    Console.Write($"{mas[i, j]}\t");
                    if (mas[i, j] > max)
                    {
                        max = mas[i, j];
                        imax = i;
                        jmax = j;
                    }
                    if (mas[i, j] < min)
                    {
                        min = mas[i, j];
                        imin = i;
                        jmin = j;
                    }
                    if (mas[i, j] == min)
                    {
                        mas[i, j] = max;
                    }
                    else if (mas[i, j] == max)
                    {
                        mas[i, j] = min;
                    }
                }
                Console.WriteLine();
            }
        }
    }
}
