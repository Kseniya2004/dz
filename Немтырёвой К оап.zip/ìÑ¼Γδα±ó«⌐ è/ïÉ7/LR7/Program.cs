﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LR7
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Лабораторная работа №7");
            Console.WriteLine("Выполнила студентка 2 курса группы ИСП.20А Немтырёва Ксения");
            Console.WriteLine("Задание 1");
            Console.WriteLine("Введите исходную строку:");
            string line = Console.ReadLine(); //исходная строка
            HashSet<char> setLine = TranslateLineToSet(line); //множество символов исходной строки
            PrintSet(setLine);            
            HashSet<char> setDigit = new HashSet<char> { 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', '+', '-', '*', '/' };// множество символов, которые нужно найти
            Console.WriteLine("Множество символов, которые нужно найти:");
            PrintSet(setDigit);
            HashSet<char> newSet = setLine; // копия исходного множества
            newSet.IntersectWith(setDigit); //пересечение 
            Console.WriteLine("Пересечение:");
            PrintSet(newSet);
            Console.ReadKey();

            Console.WriteLine("Задание 2");             
            string[] spisok = {"Abutalybly","Wasina","Glazkova","Gybin","Zhukov",
                "Ionin","Kasatkin", "Kashirin","Kuznecov","Kulakov"};
            string[] spisok1 = { "Abutalybly","Gybin","Zhukov","Ionin","Kasatkin"};
            string[] spisok2 = { "Abutalybly","Gybin","Zhukov","Kashirin","Kulakov" };
            string[] spisok3 = { "Abutalybly","Wasina","Glazkova"};
            string[] spisok4 = { "Abutalybly","Glazkova","Zhukov","Kasatkin"};
            string[] spisok5 = { "Abutalybly","Wasina","Gybin","Ionin","Kashirin","Kulakov"};
            Console.WriteLine("Список:");
            PrintSet(spisok);
            Console.WriteLine("Список1:");
            PrintSet(spisok1);
            Console.WriteLine("Список2:");
            PrintSet(spisok2);
            Console.WriteLine("Список3:");
            PrintSet(spisok3);
            Console.WriteLine("Список4:");
            PrintSet(spisok4);
            Console.WriteLine("Список5:");
            PrintSet(spisok5);
            Console.WriteLine("------------");

            Console.WriteLine("Входит во все множества:");
            PrintSet(spisok1.Intersect(spisok2).Intersect(spisok3).Intersect(spisok4).Intersect(spisok5));

            Console.WriteLine("НЕ входит ни в одно множества:");
            PrintSet(spisok.Except(spisok1).Except(spisok2).Except(spisok3).Except(spisok4).Except(spisok5));

            Console.WriteLine("Входят в третье и четвертое множества:");
            PrintSet(spisok3.Intersect(spisok4));
            Console.ReadKey();
        }
        private static HashSet<char> TranslateLineToSet(string word)
        {
            HashSet<char> setWord = new HashSet<char>();
            foreach (char c in word)
            {
                setWord.Add(c);
            }
            return setWord;
        }
        private static void PrintSet(HashSet<char> set)
        {
            foreach (char c in set)
            {
                Console.Write($"{c} ");
            }
            Console.WriteLine();
        }
        private static void PrintSet(IEnumerable<string> set)
        {
            foreach (string c in set)
            {
                Console.Write($"{c} ");
            }
            Console.WriteLine();
        }
    }
}
