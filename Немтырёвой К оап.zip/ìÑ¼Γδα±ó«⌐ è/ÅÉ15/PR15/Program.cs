﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PR15
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Практическая работа № 15");
            Console.WriteLine("Выполнила Немтырёва Ксения студентка 2 курса группы ИСП.20А");
            Console.WriteLine("Вариант 4");
            string[] Class = { "Ivav", "Vova", "Nikolay", "Kseniya", "Anna" };
            string[] I = { "Vova", "Anna" };
            string[] V = { "Ivan", "Nikolay", "Kseniya", "Vova", "Anna" };
            string[] N = { "Ivav", "Kseniya", "Nikolay", "Anna" };
            string[] K = { "Ivav", "Vova", "Nikolay", "Anna", "Kseniya" };
            string[] A = { "Ivav", "Nikolay", "Kseniya", "Anna" };
            Console.WriteLine($"Список класса:");
            Print_mnozh(Class);
            Console.WriteLine(".........");
            Console.WriteLine("Человек, который побыл в гостях у всех учеников:");
            Print_mnozh(I.Intersect(V).Intersect(N).Intersect(K).Intersect(A));

            Console.WriteLine("-----------");

            Console.WriteLine("Вариант 2");
            Console.WriteLine("2.Дан текст из строчных латинских букв. Вывести все буквы, входящие в этот текст не менее двух раз.");
            Console.WriteLine("Введите текст");
            string text = Console.ReadLine();
            HashSet<char> setText = TranslateLineToSet(text);
            Console.WriteLine("Символы, которые входят более 2 раз:");
            foreach(char c in setText)
            {
                int counter = 0;
                foreach(char b in text)
                {
                    if (c == b)
                    {
                        counter++;
                        if (counter == 2)
                        {
                            Console.Write($"{c} ");
                            break;
                        }
                    }
                }
            }

            Console.ReadKey();

        }
        private static void Print_mnozh(IEnumerable<string> res)
        {
            foreach (string s in res)
                Console.WriteLine(s);
        }
        private static HashSet<char> TranslateLineToSet(string word)
        {
            HashSet<char> setWord = new HashSet<char>();
            foreach (char c in word)
            {
                setWord.Add(c);
            }
            return setWord;
        }
    }
}
