﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PR11
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Немтырёвой Ксении, 2 вариант");
            Console.WriteLine("Введите два слова с клавиатуры. Соедините их, определите длину строки полученного слова. " +
                "Напечатайте введённые слова, полученное слово и его длину.");
            Console.WriteLine("Введите первое слово");
            String a = Console.ReadLine();
            Console.WriteLine("Введите второе слово");
            String b = Console.ReadLine();
            int a1 = a.Length;
            int b1 = b.Length;
            Console.WriteLine($"Количество символов первого слова: {a1}. Количество символов второго слова: {b1}");
            // 1 
            Console.WriteLine("1 способ");
            String c = a + b;
            Console.WriteLine(c);
            // 2
            Console.WriteLine("2 способ");
            String d = String.Concat(c);
            Console.WriteLine(d);
            //3
            Console.WriteLine("3 способ");
            string[] values = new string[] { a, b };
            String e = String.Join("",values);
            Console.WriteLine(e);
            Console.ReadKey();
        }
    }
}
