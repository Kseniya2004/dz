﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KR1
{
    class Program
    {
        static void Main(string[] args)
        {
            string S = "паркет";

            string Z = S.Substring(0, 4);
            Console.WriteLine(Z);
            Console.ReadLine();
            //Console.WriteLine("Немтырёва Ксения");
            //Console.WriteLine("Практическая работа №14, вариант 2");
            //Console.WriteLine("Задание 1");
            //int[,] mas = new int[5, 5];
            //for (int i = 0; i < 5; i++)
            //{
            //    for (int j = 0; j < 5; j++)
            //    {
            //        if (i <= j)
            //            mas[i, j] = 1;
            //        else
            //            mas[i, j] = 0;
            //        Console.Write($"{mas[i, j]}\t");
            //    }
            //    Console.WriteLine();
            //}
            //Console.ReadKey();

            //Console.WriteLine("Задание 2");
            //Console.WriteLine("Вариант 14");
            //Console.WriteLine("Вычислить сумму отрицательных элементов массива. Найти максимальный элемент.");
            //Random R = new Random();
            //Console.WriteLine("Введите размер массива N");
            //int N = int.Parse(Console.ReadLine());
            //Console.WriteLine("Введите размер массива M");
            //int M = int.Parse(Console.ReadLine());
            //int[,] mas1 = new int[N, M];
            //Console.WriteLine("Mассив");
            //for (int i = 0; i < 5; i++)
            //{
            //    for (int j = 0; j < 5; j++)
            //    {
            //        mas1[i, j] = R.Next(-100, 100);
            //        Console.Write($"{mas1[i, j]}\t");
            //    }
            //    Console.WriteLine();
            //}
            //int sum = 0;
            //int max = 0;
            //for (int i = 0; i < 5; i++)
            //{
            //    for (int j = 0; j < 5; j++)
            //    {
            //        if (mas1[i, j] < 0)
            //            sum += mas1[i, j];
            //        if (mas1[i, j] > max)
            //            max = mas1[i,j];
            //    }

            //}
            //Console.WriteLine($"Сумма отрицательных элементов: {sum}");
            //Console.WriteLine($"Максимальный элемент массива: {max}");
            //Console.ReadKey();
        }
    }
}
