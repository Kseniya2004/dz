﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PR6
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            b1.Content = "2";
            b1.FontSize = 24;
        }
        private void Button1_Click(object sender, RoutedEventArgs e)
        {
            b2.Content = "2";
            b2.FontSize = 24;
        }
        private void Button2_Click(object sender, RoutedEventArgs e)
        {
            b3.Content = "1";
            b3.FontSize = 24;
        }
        private void Button3_Click(object sender, RoutedEventArgs e)
        {
            b4.Content = "Мина!";
            b4.Background = new SolidColorBrush(Colors.Gray);
            b4.FontSize = 24;

        }
        private void Button4_Click(object sender, RoutedEventArgs e)
        {
            b5.Content = "Мина!";
            b5.Background = new SolidColorBrush(Colors.Gray);
            b5.FontSize = 24;
        }
        private void Button5_Click(object sender, RoutedEventArgs e)
        {
            b6.Content = "2";
            b6.FontSize = 24;
        }
        private void Button6_Click(object sender, RoutedEventArgs e)
        {
            b7.Content = "3";
            b7.FontSize = 24;
        }
        private void Button7_Click(object sender, RoutedEventArgs e)
        {
            b8.Content = "Мина!";
            b8.Background = new SolidColorBrush(Colors.Gray);
            b8.FontSize = 24;
        }
        private void Button8_Click(object sender, RoutedEventArgs e)
        {
            b9.Content = "2";
            b9.FontSize = 24;
        }
        
    }
    
}
