﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MDK_Pr1
{
    class Program
    {
        static void Main(string[] args)
        {
            //1
            /*string a = Console.ReadLine();
            if (a.Length >= 5)
            {
                Console.WriteLine(a[4]);
            }
            else
                Console.WriteLine("Нет");
            // 2
            if (a[0] == 'а')
            {
                Console.WriteLine("Да");
            }
            else
                Console.WriteLine("Нет");

            //3
            int b = a.Length - 1;           
            Console.WriteLine(a[b]);

            //4            
            string a2 = Console.ReadLine();
            if (a[b]== a2[0])   
            {
                Console.WriteLine("Верно");
            }
            else 
            {
                Console.WriteLine("Неверно");
            }

            //6
            foreach (char c in a)
            {
                Console.WriteLine(c);
            }

          

            //7
            int z = Convert.ToInt32(Console.ReadLine());
            if (a.Length >= z)
            {
                Console.WriteLine(a[z-1]);
            }
            else
                Console.WriteLine("Ошибка"); */
            string a = Console.ReadLine();
            int b = a.Length - 1;
            string a2 = Console.ReadLine();
            while ( a2[0]==a[b])
            {
                a = a2;
                b = a.Length - 1;
                a2 = Console.ReadLine();               
            }
            Console.WriteLine(a2);
            Console.ReadKey();

        }
    }
}
