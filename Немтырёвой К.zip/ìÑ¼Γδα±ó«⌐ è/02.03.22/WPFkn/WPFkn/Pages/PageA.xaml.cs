﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPFkn.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageA.xaml
    /// </summary>
    public partial class PageA : Page
    {
        public PageA()
        {
            InitializeComponent();
        }

        private void btnCalc_Click(object sender, RoutedEventArgs e)
        {
            double x = double.Parse(txtx.Text);
            double y = double.Parse(txty.Text);
            double rezult = Math.Round(Math.Pow(2, -x)-Math.Cos(x)+Math.Sin(2*x*y),2);
            txtresult.Text = rezult.ToString();
        }
    }
}
