﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LB1.Pages
{
    /// <summary>
    /// Логика взаимодействия для Page1.xaml
    /// </summary>
    public partial class Page1 : Page
    {
        public Page1()
        {
            InitializeComponent();
        }

        private void btnCalc_Click(object sender, RoutedEventArgs e)
        {
            double x = double.Parse(txtx.Text);
            double y = double.Parse(txty.Text);
            double z = double.Parse(txtz.Text);
            double rezult = Math.Round(Math.Pow(y, x + 1) / (Math.Pow(Math.Abs(y - 2), 0.333) + 3) + (x + (y / 2)) / (2 * Math.Abs(x + y)) * Math.Pow((x + 1), -1 / Math.Sin(z)),4);
            rez.Text = rezult.ToString();
        }
    }
}
